
from .base import Membresia

class MembresiaPremium(Membresia):
    def calcular_costo_mensual(self):
        return 60
    def obtener_horarios_permitidos(self):
        return "24 horas"
