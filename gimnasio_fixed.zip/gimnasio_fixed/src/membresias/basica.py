
from .base import Membresia

class MembresiaBasica(Membresia):
    def calcular_costo_mensual(self):
        return 30
    def obtener_horarios_permitidos(self):
        return "6am - 6pm"
