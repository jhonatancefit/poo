
from .base import Membresia

class MembresiaFamiliar(Membresia):
    def __init__(self,num,tit,fecha,integrantes):
        super().__init__(num,tit,fecha)
        self.integrantes=integrantes

    def calcular_costo_mensual(self):
        return 40*self.integrantes

    def obtener_horarios_permitidos(self):
        return "6am - 10pm"
