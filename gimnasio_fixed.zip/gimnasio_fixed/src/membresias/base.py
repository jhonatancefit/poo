
from abc import ABC, abstractmethod

class Membresia(ABC):
    def __init__(self, numero, titular, fecha):
        self.__numero = numero
        self.__titular = titular
        self.__fecha = fecha
        self.__estado = True
        self._servicios_incluidos=[]
        self._historial_pagos=[]
        self.__costo_base=0

    @abstractmethod
    def calcular_costo_mensual(self): ...

    @abstractmethod
    def obtener_horarios_permitidos(self): ...

    def renovar_membresia(self):
        self.__estado=True

    def __str__(self):
        return f"Membresia({self.__titular})"
