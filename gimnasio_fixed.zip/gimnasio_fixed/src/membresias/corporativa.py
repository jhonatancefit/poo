
from .base import Membresia

class MembresiaCorporativa(Membresia):
    def __init__(self,num,tit,fecha,empresa,empleados):
        super().__init__(num,tit,fecha)
        self.empresa=empresa
        self.empleados=empleados

    def calcular_costo_mensual(self):
        return 25*self.empleados

    def obtener_horarios_permitidos(self):
        return "24 horas + áreas corporativas"
