
from abc import ABC, abstractmethod

class Equipo(ABC):
    def __init__(self,cod,nombre,fecha,valor):
        self.__cod=cod
        self._nombre=nombre
        self.__fecha=fecha
        self._valor=valor
        self._historial_mantenimiento=[]

    @abstractmethod
    def calcular_depreciacion(self): ...

    @abstractmethod
    def frecuencia_mantenimiento_dias(self): ...

    def registrar_mantenimiento(self,fecha):
        self._historial_mantenimiento.append(fecha)
