
from .base import Equipo

class EquipoFuncional(Equipo):
    def calcular_depreciacion(self):
        return self._valor*0.10
    def frecuencia_mantenimiento_dias(self):
        return 60
