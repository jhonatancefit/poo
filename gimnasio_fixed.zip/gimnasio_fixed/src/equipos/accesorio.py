
from .base import Equipo

class Accesorio(Equipo):
    def calcular_depreciacion(self):
        return self._valor*0.20
    def frecuencia_mantenimiento_dias(self):
        return 15
