
from .base import Equipo

class Pesa(Equipo):
    def calcular_depreciacion(self):
        return self._valor*0.05
    def frecuencia_mantenimiento_dias(self):
        return 180
