
from .base import Equipo

class MaquinaCardio(Equipo):
    def __init__(self,cod,nombre,fecha,valor,horas):
        super().__init__(cod,nombre,fecha,valor)
        self.horas=horas

    def calcular_depreciacion(self):
        return self._valor*0.15

    def frecuencia_mantenimiento_dias(self):
        return 30
