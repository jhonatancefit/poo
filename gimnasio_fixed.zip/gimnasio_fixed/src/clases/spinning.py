
from .base import ClaseGrupal

class ClaseSpinning(ClaseGrupal):
    def __init__(self,nombre,inst,hor,dur,bicis):
        super().__init__(nombre,inst,hor,dur)
        self.bicis=bicis
    def calcular_cupo_maximo(self): return min(15,self.bicis)
    def calcular_calorias_quemadas(self,intensidad=1.0):
        return 70*8*(self._duracion/60)*(intensidad or 1)
