
from .base import ClaseGrupal

class ClaseYoga(ClaseGrupal):
    def calcular_cupo_maximo(self): return 20
    def calcular_calorias_quemadas(self,intensidad=1.0):
        return 70*4*(self._duracion/60)*(intensidad or 1)
