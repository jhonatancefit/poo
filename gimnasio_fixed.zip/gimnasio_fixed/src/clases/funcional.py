
from .base import ClaseGrupal

class ClaseFuncional(ClaseGrupal):
    def calcular_cupo_maximo(self): return 25
    def calcular_calorias_quemadas(self,intensidad=1.0):
        return 70*6*(self._duracion/60)*(intensidad or 1)
