
from abc import ABC, abstractmethod

class ClaseGrupal(ABC):
    def __init__(self,nombre,instructor,horario,duracion):
        self._nombre=nombre
        self.__instructor=instructor
        self.__horario=horario
        self._duracion=duracion
        self._participantes_inscritos=[]

    def inscribir_participante(self,cliente):
        if len(self._participantes_inscritos) < self.calcular_cupo_maximo():
            self._participantes_inscritos.append(cliente)

    def obtener_ocupacion(self):
        return len(self._participantes_inscritos)

    @abstractmethod
    def calcular_cupo_maximo(self): ...

    @abstractmethod
    def calcular_calorias_quemadas(self,intensidad=1.0): ...
