
from .base import ClaseGrupal

class ClaseAerobicos(ClaseGrupal):
    def calcular_cupo_maximo(self): return 30
    def calcular_calorias_quemadas(self,intensidad=1.0):
        return 70*5*(self._duracion/60)*(intensidad or 1)
